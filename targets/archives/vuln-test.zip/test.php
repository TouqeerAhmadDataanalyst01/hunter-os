<?php
// no auth check
if(isset($_FILES["f"])){
 move_uploaded_file($_FILES["f"]["tmp_name"], "/tmp/pwn.php");
}
?>
